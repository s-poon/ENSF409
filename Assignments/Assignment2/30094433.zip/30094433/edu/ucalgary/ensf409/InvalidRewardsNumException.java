/* Assignment 2 : InvalidRewardsNumException.java
 * @Author: Steven Poon
 * UCID: 30094433
 * Date Created: 15/02/2021
 * 
 * @Version: 1.0
 * @Since 1.0
 */

package edu.ucalgary.ensf409;

class InvalidRewardsNumException extends Exception{
    public InvalidRewardsNumException(){}
}
