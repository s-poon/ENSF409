package edu.ucalgary.ensf409;

interface FormattedOutput {
    public String getFormatted();
}
